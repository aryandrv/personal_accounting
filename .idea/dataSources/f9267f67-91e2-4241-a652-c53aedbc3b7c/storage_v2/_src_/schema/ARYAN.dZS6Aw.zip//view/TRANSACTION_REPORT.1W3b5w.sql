create view TRANSACTION_REPORT as
select U.ID     as user_id,
       U.USERNAME as user_username,
       U.NAME   as user_name,
       U.FAMILY as user_family,
       U.PASSWORD as user_password,
       U.CREATIONDATE as user_creationdate,
       A.ID     as account_id,
       A.NAME as account_name,
       A.USER_ID as account_userid,
       A.BALANCE    as account_balance,
       T.ID as titles_id,
       T.NAME as titles_name,
       T.TYPE as titles_type,
       TR.ID as transaction_id,
       TR.USER_ID as transaction_userid,
       TR.TYPE as transaction_type,
       TR.ACCOUNT_ID as transaction_accountid,
       TR.TITLES_ID as transaction_titlesid,
       TR.AMOUNT as transaction_amount,
       TR.TRANSACTIONDATE as transaction_date,
       TR.DESCRIPTION as transaction_description
from USER_TBL U,
     ACCOUNT_TBL A,
     TITLES_TBL T,
     TRANSACTION_TBL TR
where TR.USER_ID = U.ID and TR.ACCOUNT_ID = a.ID and TR.TITLES_ID = t.ID
/

