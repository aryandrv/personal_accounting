create view ACCOUNT_REPORT as
select U.ID       as user_id,
       U.NAME     as user_name,
       U.FAMILY   as user_family,
       U.USERNAME as user_username,
       U.password as user_password,
       U.creationDate as user_creationdate,
       A.ID       as account_id,
       A.NAME     as account_name,
       A.BALANCE  as account_balance,
       A.user_id  as account_userId
from ACCOUNT_TBL A,
     USER_TBL U
where A.USER_ID = U.ID
/

