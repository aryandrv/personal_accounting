create view ACCOUNT_REPORT as
select U.ID     as user_id,
       U.USERNAME as user_username,
       U.NAME   as user_name,
       U.FAMILY as user_family,
       U.PASSWORD as user_password,
       U.CREATIONDATE as user_creationdate,
       A.ID     as account_id,
       A.NAME as account_name,
       A.USER_ID as account_userid,
       A.BALANCE    as account_balance
from USER_TBL U,
     ACCOUNT_TBL A
where U.ID = A.USER_ID
/

